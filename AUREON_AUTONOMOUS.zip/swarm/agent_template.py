# agent_template.py — placeholder for Aureon Autonomous
