# ps_probe.py — placeholder for Aureon Autonomous
