# README.md — placeholder for Aureon Autonomous
